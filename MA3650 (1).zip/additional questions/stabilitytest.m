xmin = 2;
xmax = 10;
tmax = 1;
c = 5;
f0 = @(x) 2*x.^2;
Vdx = [0.001] ;
Vdt = [0.00015 0.0002 0.00025 0.00035];
count = 1;
for loop1 = 1:length(Vdx)
    for loop2 = 1:length(Vdt)
        dx = Vdx(loop1);
        dt = Vdt(loop2);
        rho = dt/dx;
        N = ceil((xmax - xmin) / dx); %makes sure the number of steps will exactly
        xmax = xmin + N*dx; %makes sure our steps will take us from the minimum to maximum values for x exactly
        M = ceil(tmax/dt); %makes sure that the number of steps will exactly take us to the maximum time
        k1 = 1 - rho*c;
        k2 = rho*c; %uses forward difference for t and backward difference for x
        solution = zeros(N+1,M+1); % a vector to store all our answer outputs
        vetx = xmin:dx:xmax; % a vector for all of our x values whilst plotting
        for i=1:N+1 %for all of our values of x
            solution(i,1) = feval(f0,vetx(i)); %calculate the initial conditions for our first row
        end
        fixedvalue = solution(1,1); %first value is value we use to calculate the values from
        % this is needed because of finite domain
        for j=1:M %for the interval for time
            solution(:,j+1) = k1*solution(:,j) + k2*[ fixedvalue ; solution(1:N,j)]; %uses a form of the forward difference using our earlier ratios
        end
        time = floor(length(solution(1,:)));
        %sets the time we are plotting to be the end of the solution
        % TransportPlot(xmin, dx, xmax, times, solution) %calls the function transport plot to plot the different times in figures
        %imported the entirety of the function into this code for simplicity
        %editting
        %plots the results for varying amounts of time on seperate subplots
        subplot(2,2,count)
        plot(xmin:dx:xmax, solution(:,time))
        %axis([xmin xmax min(solution(:,time)) max(solution(:,times(4)))])%sets the axis to fit the range
        %axis lines are commented out because automatic settings for matlab
        %actually are preferable
        title(['rho=', num2str(rho) ],'Fontsize',12);
        count = count+1;
    end
end
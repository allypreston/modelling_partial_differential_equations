% TransportPlot.m 
function TransportPlot(xmin, dx, xmax, times, solution)
%plots the results for varying amounts of time on seperate subplots
subplot(2,2,1)
plot(xmin:dx:xmax, solution(:,times(1)))
%axis([xmin xmax min(solution(:,times(1))) max(solution(:,times(1)))])%sets the axis to fit the range
subplot(2,2,2)
plot(xmin:dx:xmax, solution(:,times(2)))
%axis([xmin xmax min(solution(:,times(2))) max(solution(:,times(2)))])%sets the axis to fit the range
subplot(2,2,3)
plot(xmin:dx:xmax, solution(:,times(3)))
%axis([xmin xmax min(solution(:,times(3))) max(solution(:,times(3)))])%sets the axis to fit the range
subplot(2,2,4)
plot(xmin:dx:xmax, solution(:,times(4)))
%axis([xmin xmax min(solution(:,times(4))) max(solution(:,times(4)))])%sets the axis to fit the range 
%axis lines are commented out because automatic settings for matlab
%actually are preferable




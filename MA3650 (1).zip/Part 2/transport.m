function [solution, N, M] = transport(xmin, dx, xmax, dt, tmax, c, f0)
%eg inputs transport(0, 0.05, 6, 0.01, 1, 2, @(x) sin(x))
%or transport(1, 0.025, 2, 0.001, 0.5, 1, @(x) x.^-1)
%outputs our solution with information about the intervals and initial
%condition
N = ceil((xmax - xmin) / dx); %makes sure the number of steps will exactly
xmax = xmin + N*dx; %makes sure our steps will take us from the minimum to maximum values for x exactly
M = ceil(tmax/dt); %makes sure that the number of steps will exactly take us to the maximum time
k1 = 1 - dt*c/dx;
k2 = dt*c/dx; %uses forward difference for t and backward difference for x
solution = zeros(N+1,M+1); % a vector to store all our answer outputs
vetx = xmin:dx:xmax; % a vector for all of our x values whilst plotting
for i=1:N+1 %for all of our values of x
   solution(i,1) = feval(f0,vetx(i)); %calculate the initial conditions for our first row
end
fixedvalue = solution(1,1); %first value is value we use to calculate the values from
% this is needed because of finite domain 
for j=1:M %for the interval for time
   solution(:,j+1) = k1*solution(:,j) + k2*[ fixedvalue ; solution(1:N,j)]; %uses a form of the forward difference using our earlier ratios
end
times = [1, floor(length(solution(1,:))/3), floor(2*length(solution(1,:))/3), floor(length(solution(1,:)))];
%divides the solution into intervals that work for the arbitrary length of the solution



% TransportPlot(xmin, dx, xmax, times, solution) %calls the function transport plot to plot the different times in figures
%imported the entirety of the function into this code for simplicity
%editting
%plots the results for varying amounts of time on seperate subplots
subplot(2,2,1)
plot(xmin:dx:xmax, solution(:,times(1)))
title(['t =', num2str((times(1)-1)*dt)])
%axis([xmin xmax min(solution(:,times(1))) max(solution(:,times(1)))])%sets the axis to fit the range
subplot(2,2,2)
plot(xmin:dx:xmax, solution(:,times(2)))
title(['t =', num2str((times(2)-1)*dt)])
%axis([xmin xmax min(solution(:,times(2))) max(solution(:,times(2)))])%sets the axis to fit the range
subplot(2,2,3)
plot(xmin:dx:xmax, solution(:,times(3)))
title(['t =', num2str((times(3)-1)*dt)])
%axis([xmin xmax min(solution(:,times(3))) max(solution(:,times(3)))])%sets the axis to fit the range
subplot(2,2,4)
plot(xmin:dx:xmax, solution(:,times(4)))
title(['t =', num2str((times(4)-1)*dt)])
%axis([xmin xmax min(solution(:,times(4))) max(solution(:,times(4)))])%sets the axis to fit the range 
%axis lines are commented out because automatic settings for matlab
%actually are preferable
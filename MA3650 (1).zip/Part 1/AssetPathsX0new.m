x0=[5 10 15 20 25 40]'; %initial starting values
NSteps=18000; %number of steps for our simulation
T = [180]; %the numbers of time steps for our code
sigma=[0]; %the volatility of the code
r=0.05; %value for the growth rate
K=20; %carrying capacity of our simulation

x = zeros(length(x0), 1 + NSteps); %our vector to store all our values in
x(:,1) = x0; %defines the starting value 
dt = T/NSteps; %creates our 'small' value for change in time
sidt = sigma*sqrt(dt); %forms our second part of the eaquation which has the variation
t=linspace(0, T, NSteps+1); %evenly divides our time into equal intervals for the whole investigation
for j=1:NSteps %for each value in our range
    x(:,j+1) = x(:,j).*(1+r*(1-(x(:,j))/K)*dt + sidt*randn(length(sigma), 1)); %run our simulation for the logistic equation            
end
plot(t,x, 'linewidth', 2.5) %plots our result
title({'Typical Solutions of the Deterministic Logistic Model';'for different starting values'},'Fontsize', 25)
ylabel('Population')
xlabel('Time')
legend({num2str(x0(1)),num2str(x0(2)),num2str(x0(3)),num2str(x0(4)),num2str(x0(5)),num2str(x0(6))},'location', 'best', 'Fontsize', 20)
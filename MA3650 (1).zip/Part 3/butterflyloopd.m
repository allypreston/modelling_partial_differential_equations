for d = 1:100
dx = 0.05; % step in x direction
dy = 0.05; % step in y direction
dt = 0.0001; %step in t direction
tmax = 0.01; %maximum time for our model
y = 2; %upper bound of y
a = 24/7;
b = 6;
K = 1/3;
alpha = 3/7;
gamma = 0.1;
rho = 1/5;
uhat = 3;
vhat = 5; %chosen variables


cx = dt/dx^2;
cy = dt/dy^2; %sets up our ratios for later

if cx + cy > 0.5
    disp('Warning, bad step sizes')
end


numbert = tmax/dt;
numberx = 1/dx;
numbery = y/dy; %sets up number of steps for t, x and y

Lu = 0.75*uhat*ones(1+numberx, 1+numbery, 2);
Lv = 1.25*vhat*ones(1+numberx, 1+numbery, 2);
[X, Y] = meshgrid(0:dx:1, 0:dy,y);


for k = 1:numbert
    for i = 2:numberx
        for j = 2:numbery
            huv = h(Lu(i,j,1),Lv(i,j,1), rho, K);
            Lu(i,j, 2) = Lu(i,j,1)*(1-2*cx - 2*cy) + cx*(Lu(i+1,j,1) + Lu(i-1,j,1)) + ...
                cy*(Lu(i,j+1,1) + Lu(i,j-1,1)) + dt*gamma*(a - Lu(i,j,1) - huv);
            Lv(i,j, 2) = Lv(i,j,1)*(1-2*d*cx - 2*d*cy) + d*cx*(Lv(i+1,j,1) + Lv(i-1,j,1)) + ...
                d*cy*(Lv(i,j+1,1) + Lv(i,j-1,1)) + dt*gamma*(alpha*(b-Lv(i,j,1)) - huv);            
                Lu(1,j,2) = Lu(2,j,1);
                Lu(1+numberx,j,2) = Lu(numberx, j,1); 
                Lv(1,j,2) = Lv(2,j,1);
                Lv(1+numberx,j,2) = Lv(numberx, j,1);
        end
        Lu(i,1,2) = Lu(i,2,1); 
        Lu(i,1+numbery,2) = Lu(i,numbery,1);
        Lv(i,1,2) = Lv(i,2,1); 
        Lv(i,1+numbery,2) = Lv(i,numbery,1); 
    end
    Lu(1,1,2) = Lu(2,2,1); 
    Lu(1+numberx,1+numbery,2) = Lu(numberx,numbery,1);
    Lu(1,1+numbery,2) = Lu(2,numbery,1);
    Lu(1+numberx,1,2) = Lu(numberx,2,1); 
    Lv(1,1,2) = Lv(2,2,1); 
    Lv(1+numberx,1+numbery,2) = Lv(numberx,numbery,1);
    Lv(1,1+numbery,2) = Lv(2,numbery,1);
    Lv(1+numberx,1,2) = Lv(numberx,2,1); 
    Lu(:,:,1) = Lu(:,:,2);    
    Lv(:,:,1) = Lv(:,:,2);
end
final = Lu(:,:,2);
for loop = 1:numel(final)
    if final(loop) < uhat/2
        final(loop) = 1;
    elseif final(loop) < uhat
        final(loop) = 2;
    elseif final(loop) < 1.5*uhat
        final(loop) = 3;
    elseif final(loop) > 1.5*uhat
        final(loop) = 4;
    end
end


U = final(:,:);
figure
imagesc(U)
colormap(cool)
colorbar
end
function huv = h(u,v,rho,k)
huv = (rho*u*v)/(1+u+k*u^2); 
end